# Ciphers

Ciphers are used to protect data from people that are not allowed to have it. They are everywhere on the internet to protect your connections.

* <https://en.wikipedia.org/wiki/Cipher>
* <http://practicalcryptography.com/ciphers/>
* <https://practicalcryptography.com/ciphers/classical-era/>
